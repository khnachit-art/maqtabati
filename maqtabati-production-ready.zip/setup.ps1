<#
.SYNOPSIS
    تثبيت تطبيق إدارة طلبات الكتب المدرسية - PowerShell Script
.DESCRIPTION
    يثبت التبعيات، يهيئ قاعدة البيانات، ويزرع البيانات الأولية
.NOTES
    يعمل على Windows مع PowerShell 5.1+
#>

$ErrorActionPreference = "Stop"

Write-Host ""
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host "   تطبيق إدارة طلبات الكتب المدرسية - سكريبت التنصيب (PowerShell)" -ForegroundColor Cyan
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host ""

# التحقق من وجود Node.js
try {
    $nodeVersion = node --version 2>$null
    if (-not $nodeVersion) { throw "Node not found" }
    Write-Host "[OK] Node.js $nodeVersion متوفر" -ForegroundColor Green
} catch {
    Write-Host "[خطأ] Node.js غير مثبت!" -ForegroundColor Red
    Write-Host ""
    Write-Host "يرجى تثبيت Node.js 18+ من: https://nodejs.org/en/download" -ForegroundColor Yellow
    Write-Host "أو باستخدام: winget install OpenJS.NodeJS" -ForegroundColor Yellow
    Write-Host ""
    Read-Host "اضغط Enter للخروج"
    exit 1
}

# التحقق من إصدار Node.js
$majorVersion = [int]($nodeVersion.TrimStart('v').Split('.')[0])
if ($majorVersion -lt 18) {
    Write-Host "[تحذير] إصدار Node.js الحالي: $nodeVersion (مطلوب 18+)" -ForegroundColor Yellow
    Write-Host "يوصى بتحديث Node.js من: https://nodejs.org" -ForegroundColor Yellow
    Write-Host ""
}

# التحقق من npm
try {
    npm --version 2>$null | Out-Null
    Write-Host "[OK] npm متوفر" -ForegroundColor Green
} catch {
    Write-Host "[خطأ] npm غير متوفر!" -ForegroundColor Red
    Read-Host "اضغط Enter للخروج"
    exit 1
}

Write-Host ""

# تنظيف تثبيت سابق (اختياري)
if (Test-Path "node_modules") {
    Write-Host "[معلومة] تم العثور على تثبيت سابق" -ForegroundColor Yellow
    $reinstall = Read-Host "هل تريد إعادة التثبيت من الصفر؟ (y/N)"
    if ($reinstall -ieq 'y') {
        Write-Host "[تنظيف] حذف node_modules و package-lock.json..." -ForegroundColor Yellow
        Remove-Item -Recurse -Force "node_modules" -ErrorAction SilentlyContinue
        Remove-Item "package-lock.json" -ErrorAction SilentlyContinue
        Write-Host "[OK] تم التنظيف" -ForegroundColor Green
    }
}

Write-Host ""
Write-Host "[تثبيت] جاري تثبيت التبعيات... (قد يستغرق بضع دقائق)" -ForegroundColor Cyan
Write-Host ""

try {
    npm install
    Write-Host ""
    Write-Host "[OK] تم تثبيت التبعيات بنجاح" -ForegroundColor Green
} catch {
    Write-Host ""
    Write-Host "[خطأ] فشل التثبيت!" -ForegroundColor Red
    Write-Host "جرب: npm cache clean --force ثم أعد المحاولة" -ForegroundColor Yellow
    Read-Host "اضغط Enter للخروج"
    exit 1
}

Write-Host ""

# تهيئة قاعدة البيانات
Write-Host "[قاعدة البيانات] تهيئة Prisma..." -ForegroundColor Cyan
npx prisma generate

Write-Host "[قاعدة البيانات] تطبيق الترحيلات..." -ForegroundColor Cyan
npx prisma migrate deploy

Write-Host "[قاعدة البيانات] زرع البيانات الأولية..." -ForegroundColor Cyan
npm run db:seed

Write-Host ""
Write-Host "============================================================" -ForegroundColor Green
Write-Host "   [نجاح] اكتمل التنصيب بنجاح!" -ForegroundColor Green
Write-Host "============================================================" -ForegroundColor Green
Write-Host ""
Write-Host "لتشغيل التطبيق، شغل: .\start.ps1" -ForegroundColor Cyan
Write-Host "أو شغل يدوياً: npm run dev" -ForegroundColor Cyan
Write-Host ""
Write-Host "سيتم فتح المتصفح على: http://localhost:3000" -ForegroundColor Cyan
Write-Host ""
Read-Host "اضغط Enter للخروج"