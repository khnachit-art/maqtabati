<#
.SYNOPSIS
    تشغيل تطبيق إدارة طلبات الكتب المدرسية - PowerShell Script
.DESCRIPTION
    يتحقق من التنصيب ويشغل خادم التطوير
#>

$ErrorActionPreference = "Stop"

Write-Host ""
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host "   تطبيق إدارة طلبات الكتب المدرسية" -ForegroundColor Cyan
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host ""

# التحقق من وجود node_modules
if (-not (Test-Path "node_modules")) {
    Write-Host "[خطأ] التبعيات غير مثبتة!" -ForegroundColor Red
    Write-Host "يرجى تشغيل .\setup.ps1 أولاً" -ForegroundColor Yellow
    Write-Host ""
    Read-Host "اضغط Enter للخروج"
    exit 1
}

# التحقق من قاعدة البيانات
if (-not (Test-Path "prisma\dev.db")) {
    Write-Host "[معلومة] قاعدة البيانات غير موجودة، جاري إنشاؤها..." -ForegroundColor Yellow
    npx prisma migrate deploy
    npm run db:seed
    Write-Host ""
}

Write-Host "[تشغيل] جاري تشغيل خادم التطوير..." -ForegroundColor Cyan
Write-Host ""
Write-Host "سيتم فتح المتصفح تلقائياً على: http://localhost:3000" -ForegroundColor Green
Write-Host ""
Write-Host "اضغط Ctrl+C للإيقاف" -ForegroundColor Gray
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host ""

# فتح المتصفح
Start-Process "http://localhost:3000"

npm run dev