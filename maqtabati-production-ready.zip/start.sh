#!/bin/bash
# سكريبت تشغيل التطبيق - macOS / Linux

set -e

echo ""
echo "============================================================"
echo "   تطبيق إدارة طلبات الكتب المدرسية"
echo "============================================================"
echo ""

# التحقق من وجود node_modules
if [ ! -d "node_modules" ]; then
    echo "[خطأ] التبعيات غير مثبتة!"
    echo "يرجى تشغيل ./setup.sh أولاً"
    echo ""
    exit 1
fi

# التحقق من قاعدة البيانات
if [ ! -f "prisma/dev.db" ]; then
    echo "[معلومة] قاعدة البيانات غير موجودة، جاري إنشاؤها..."
    npx prisma migrate deploy
    npm run db:seed
    echo ""
fi

echo "[تشغيل] جاري تشغيل خادم التطوير..."
echo ""
echo "سيتم فتح المتصفح تلقائياً على: http://localhost:3000"
echo ""
echo "اضغط Ctrl+C للإيقاف"
echo "============================================================"
echo ""

# فتح المتصفح (macOS / Linux)
if command -v open &> /dev/null; then
    open http://localhost:3000
elif command -v xdg-open &> /dev/null; then
    xdg-open http://localhost:3000
fi

npm run dev