#!/bin/bash
set -e

echo "=== Running migrations ==="
npx prisma migrate deploy || echo "Migration skipped (tables may already exist)"

echo "=== Seeding database ==="
npx tsx scripts/seed-all.ts || echo "Seed failed (continuing anyway)"

echo "=== Starting server ==="
exec next start -p ${PORT:-3000}
