@echo off
chcp 65001 >nul
title تثبيت تطبيق إدارة طلبات الكتب المدرسية

echo.
echo ============================================================
echo   تطبيق إدارة طلبات الكتب المدرسية - سكريبت التنصيب
echo ============================================================
echo.

:: التحقق من وجود Node.js
where node >nul 2>&1
if %errorlevel% neq 0 (
    echo [خطأ] Node.js غير مثبت!
    echo.
    echo يرجى تثبيت Node.js 18+ من: https://nodejs.org/en/download
    echo أو باستخدام: winget install OpenJS.NodeJS
    echo.
    pause
    exit /b 1
)

:: التحقق من إصدار Node.js
for /f "tokens=2 delims=v" %%i in ('node --version') do set NODE_VER=%%i
for /f "tokens=1 delims=." %%i in ("%NODE_VER%") do set NODE_MAJOR=%%i

if %NODE_MAJOR% lss 18 (
    echo [تحذير] إصدار Node.js الحالي: %NODE_VER% (مطلوب 18+)
    echo يوصى بتحديث Node.js من: https://nodejs.org
    echo.
) else (
    echo [OK] Node.js %NODE_VER% متوفر
)

where npm >nul 2>&1
if %errorlevel% neq 0 (
    echo [خطأ] npm غير متوفر!
    pause
    exit /b 1
)

echo [OK] npm متوفر
echo.

:: تنظيف تثبيت سابق (اختياري)
if exist node_modules (
    echo [معلومة] تم العثور على تثبيت سابق
    echo هل تريد إعادة التثبيت من الصفر؟ (y/N)
    set /p REINSTALL=
    if /i "%REINSTALL%"=="y" (
        echo [تنظيف] حذف node_modules و package-lock.json...
        rmdir /s /q node_modules 2>nul
        del package-lock.json 2>nul
        echo [OK] تم التنظيف
    )
)

echo.
echo [تثبيت] جاري تثبيت التبعيات... (قد يستغرق بضع دقائق)
echo.

npm install
if %errorlevel% neq 0 (
    echo.
    echo [خطأ] فشل التثبيت!
    echo جرب: npm cache clean --force ثم أعد المحاولة
    pause
    exit /b 1
)

echo.
echo [OK] تم تثبيت التبعيات بنجاح
echo.

:: تهيئة قاعدة البيانات
echo [قاعدة البيانات] تهيئة Prisma...
npx prisma generate
if %errorlevel% neq 0 (
    echo [خطأ] فشل توليد Prisma Client
    pause
    exit /b 1
)

echo [قاعدة البيانات] تطبيق الترحيلات...
npx prisma migrate deploy
if %errorlevel% neq 0 (
    echo [خطأ] فشل تطبيق الترحيلات
    pause
    exit /b 1
)

echo [قاعدة البيانات] زرع البيانات الأولية...
npm run db:seed
if %errorlevel% neq 0 (
    echo [تحذير] فشل زرع البيانات (قد تكون موجودة مسبقاً)
)

echo [قاعدة البيانات] إنشاء حساب المدير...
npx tsx scripts/seed-admin.ts
if %errorlevel% neq 0 (
    echo [تحذير] فشل إنشاء حساب المدير (قد يكون موجوداً مسبقاً)
)

echo.
echo ============================================================
echo   [نجاح] اكتمل التنصيب بنجاح!
echo ============================================================
echo.
echo لتشغيل التطبيق، انقر نقراً مزدوجاً على: start.bat
echo أو شغل يدوياً: npm run dev
echo.
echo سيتم فتح المتصفح على: http://localhost:3000
echo.
pause