# دليل التنصيب والتشغيل - تطبيق إدارة طلبات الكتب المدرسية

## المتطلبات المسبقة
- **Node.js 18+** (موصى به: Node.js 20 LTS أو أحدث)
- **npm** (يأتي مع Node.js) أو **pnpm** أو **yarn**
- **Git** (اختياري، لاستنساخ المستودع)

### تثبيت Node.js
- **Windows**: حمل من [nodejs.org](https://nodejs.org/en/download) أو استخدم `winget install OpenJS.NodeJS`
- **macOS**: `brew install node` أو حمل من الموقع الرسمي
- **Linux**: `sudo apt install nodejs npm` (Ubuntu/Debian) أو استخدم مدير الحزم الخاص بتوزيعة النظام

---

## التنصيب السريع (Windows)

### الطريقة الأولى: سكريبت التنصيب التلقائي
```cmd
# 1. فك الضغط عن الملف
# 2. انقر نقراً مزدوجاً على setup.bat
# 3. انتظر حتى يكتمل التنصيب
# 4. انقر نقراً مزدوجاً على start.bat للتشغيل
```

### الطريقة الثانية: سطر الأوامر
```cmd
cd book-orders
npm install
npm run db:seed
npm run dev
```

---

## التنصيب السريع (macOS / Linux)

### الطريقة الأولى: سكريبت التنصيب التلقائي
```bash
# 1. فك الضغط عن الملف
# 2. افتح الطرفية (Terminal) في المجلد
# 3. اجعل السكريبت قابلاً للتنفيذ:
chmod +x setup.sh start.sh
# 4. شغل التنصيب:
./setup.sh
# 5. شغل التطبيق:
./start.sh
```

### الطريقة الثانية: سطر الأوامر
```bash
cd book-orders
npm install
npm run db:seed
npm run dev
```

---

## بعد التنصيب

يفتح المتصفح تلقائياً على: **http://localhost:3000**

### صفحات التطبيق:
| الصفحة | المسار | الوصف |
|----------|--------|---------|
| **الصفحة الرئيسية** | `/` | لوحة التحكم والروابط السريعة |
| **فهرس الكتب** | `/catalog` | إدارة قاعدة بيانات الكتب (إضافة/تعديل/حذف/فلترة) |
| **سجل الطلبات** | `/orders` | إدخال طلبات المدارس، إدارة العملاء، histórico |
| **التقرير المجمع** | `/summary` | تجميع الطلبات، تصدير PDF/Excel، وضع الطلبات كـ "مرسلة" |

---

## هيكل البيانات

### المستويات الدراسية المدعومة
```
PS, MS, GS (التعليم الأولي)
CP, CE1, CE2, CM1, CM2 (الابتدائي)
CE6, 1AC, 2AC, 3AC (الإعدادي)
TC SC, 1BAC SC EXP, 1BAC SC MATHS, 1BAC SC PC, 1BAC SEG ECO (الثانوي - علوم/تقني)
2BAC SC EXP, 2BAC SC MATHS, 2BAC SC PC, 2BAC SEG ECO (الباكالوريا)
```

### المواد الدراسية
عربية، رياضيات، علوم، علوم طبيعية، فرنسية، تاريخ جغرافيا، تقني رياضي، فلسفة، وغيرها...

---

## استيراد بيانات حقيقية (اختياري)

إذا كان لديك ملفات Excel بتنسيق "الأندلسية" أو "الآفاق" أو "نور الهدى":

```bash
# ضع ملفات Excel في مجلد data/ (أنشئه إذا لم يكن موجوداً)
# ثم شغل:
npx tsx scripts/seed-all.ts
```

---

## استكشاف الأخطاء

### خطأ "command not found: npm"
- تأكد من تثبيت Node.js بشكل صحيح
- أعد تشغيل الطرفية بعد التثبيت
- تحقق: `node --version && npm --version`

### خطأ في قاعدة البيانات
```bash
# إعادة تهيئة قاعدة البيانات من الصفر
npm run db:reset
```

### المنفذ 3000 مشغول
```bash
# Windows
set PORT=3001 && npm run dev
# macOS/Linux
PORT=3001 npm run dev
```

### مشاكل الأذونات (macOS/Linux)
```bash
chmod +x setup.sh start.sh
```

---

## النسخ الاحتياطي للبيانات

قاعدة البيانات مخزنة في: `prisma/dev.db`

للنسخ الاحتياطي:
```bash
cp prisma/dev.db prisma/dev.db.backup.$(date +%Y%m%d)
```

للاستعادة:
```bash
cp prisma/dev.db.backup.YYYYMMDD prisma/dev.db
```

---

## التحديثات المستقبلية

```bash
# سحب أحدث التغييرات (إذا كان المستودع مرتبط بـ Git)
git pull

# تحديث التبعيات
npm install

# تطبيق ترحيلات قاعدة البيانات الجديدة
npx prisma migrate deploy

# إعادة تشغيل
npm run dev
```

---

## الدعم الفني

في حالة وجود مشاكل:
1. تأكد من إصدار Node.js: `node --version` (يجب أن يكون 18+)
2. امسح `node_modules` و `package-lock.json` ثم أعد `npm install`
3. تحقق من وحدة التحكم في المتصفح (F12) للأخطاء
4. راجع ملفات السجل في `logs/` (إن وجدت)

---

**تم تطوير هذا التطبيق بتقنيات حديثة:** Next.js 16 + React 19 + Prisma + SQLite + Tailwind CSS