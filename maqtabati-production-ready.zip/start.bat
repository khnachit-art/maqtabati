@echo off
chcp 65001 >nul
title تشغيل تطبيق إدارة طلبات الكتب المدرسية

echo.
echo ============================================================
echo   تطبيق إدارة طلبات الكتب المدرسية
echo ============================================================
echo.

:: التحقق من وجود node_modules
if not exist node_modules (
    echo [خطأ] التبعيات غير مثبتة!
    echo يرجى تشغيل setup.bat أولاً
    echo.
    pause
    exit /b 1
)

:: التحقق من قاعدة البيانات
if not exist prisma\dev.db (
    echo [معلومة] قاعدة البيانات غير موجودة، جاري إنشاؤها...
    npx prisma migrate deploy
    npm run db:seed
    echo.
)

echo [تشغيل] جاري تشغيل خادم التطوير...
echo.
echo سيتم فتح المتصفح تلقائياً على: http://localhost:3000
echo.
echo اضغط Ctrl+C للإيقاف
echo ============================================================
echo.

start "" http://localhost:3000
npm run dev