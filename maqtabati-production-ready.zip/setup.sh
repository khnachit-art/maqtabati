#!/bin/bash
# سكريبت التنصيب للتطبيق - macOS / Linux

set -e

echo ""
echo "============================================================"
echo "   تطبيق إدارة طلبات الكتب المدرسية - سكريبت التنصيب"
echo "============================================================"
echo ""

# التحقق من وجود Node.js
if ! command -v node &> /dev/null; then
    echo "[خطأ] Node.js غير مثبت!"
    echo ""
    echo "يرجى تثبيت Node.js 18+:"
    echo "  macOS: brew install node"
    echo "  Ubuntu/Debian: sudo apt install nodejs npm"
    echo "  أو حمل من: https://nodejs.org/en/download"
    echo ""
    exit 1
fi

NODE_VER=$(node --version | sed 's/v//')
NODE_MAJOR=$(echo "$NODE_VER" | cut -d. -f1)

if [ "$NODE_MAJOR" -lt 18 ]; then
    echo "[تحذير] إصدار Node.js الحالي: $NODE_VER (مطلوب 18+)"
    echo "يوصى بتحديث Node.js من: https://nodejs.org"
    echo ""
else
    echo "[OK] Node.js $NODE_VER متوفر"
fi

if ! command -v npm &> /dev/null; then
    echo "[خطأ] npm غير متوفر!"
    exit 1
fi

echo "[OK] npm متوفر"
echo ""

# تنظيف تثبيت سابق (اختياري)
if [ -d "node_modules" ]; then
    echo "[معلومة] تم العثور على تثبيت سابق"
    read -p "هل تريد إعادة التثبيت من الصفر؟ (y/N) " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        echo "[تنظيف] حذف node_modules و package-lock.json..."
        rm -rf node_modules
        rm -f package-lock.json
        echo "[OK] تم التنظيف"
    fi
fi

echo ""
echo "[تثبيت] جاري تثبيت التبعيات... (قد يستغرق بضع دقائق)"
echo ""

npm install

if [ $? -ne 0 ]; then
    echo ""
    echo "[خطأ] فشل التثبيت!"
    echo "جرب: npm cache clean --force ثم أعد المحاولة"
    exit 1
fi

echo ""
echo "[OK] تم تثبيت التبعيات بنجاح"
echo ""

# تهيئة قاعدة البيانات
echo "[قاعدة البيانات] تهيئة Prisma..."
npx prisma generate

if [ $? -ne 0 ]; then
    echo "[خطأ] فشل توليد Prisma Client"
    exit 1
fi

echo "[قاعدة البيانات] تطبيق الترحيلات..."
npx prisma migrate deploy

if [ $? -ne 0 ]; then
    echo "[خطأ] فشل تطبيق الترحيلات"
    exit 1
fi

echo "[قاعدة البيانات] زرع البيانات الأولية..."
npm run db:seed

if [ $? -ne 0 ]; then
    echo "[تحذير] فشل زرع البيانات (قد تكون موجودة مسبقاً)"
fi

echo ""
echo "============================================================"
echo "   [نجاح] اكتمل التنصيب بنجاح!"
echo "============================================================"
echo ""
echo "لتشغيل التطبيق: ./start.sh"
echo "أو شغل يدوياً: npm run dev"
echo ""
echo "سيتم فتح المتصفح على: http://localhost:3000"
echo ""